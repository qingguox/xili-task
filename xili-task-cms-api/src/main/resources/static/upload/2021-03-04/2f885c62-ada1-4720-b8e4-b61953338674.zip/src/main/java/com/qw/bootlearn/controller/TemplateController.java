package com.qw.bootlearn.controller;

import com.qw.bootlearn.model.ArticleVO;
import com.qw.bootlearn.service.ArticleRestService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/templates")
public class TemplateController {

    @Resource
    ArticleRestService articleRestService;

    @GetMapping("/jsp")
    public String index(String name, Model model) {

        List<ArticleVO> articles = articleRestService.getAll();

        model.addAttribute("articles", articles);

        //模版名称，实际的目录为：src/main/webapp/WEB-INF/jsp/jsptemp.jsp
        return "jsptemp";
    }

    @GetMapping("/freemarker")
    public String index(Model model) {

        List<ArticleVO> articles = articleRestService.getAll();

        model.addAttribute("articles", articles);

        //模版名称，实际的目录为：resources/templates/fremarkertemp.html
        return "freemarkertemp";
    }

    @GetMapping("/thymeleaf")
    public String index2(Model model, HttpSession httpSession) {

        List<ArticleVO> articles = articleRestService.getAll();

        model.addAttribute("articles", articles);

        Map<String, String> user = new HashMap<>();
        user.put("id", "1");
        user.put("username", "k8s");
        user.put("password", "123456");

        model.addAttribute("user", user);

        httpSession.setAttribute("foo", "hhhasdakdsa");

        //模版名称，实际的目录为：resources/templates/thymeleaftemp.html
        return "thymeleaftemp";
    }
}