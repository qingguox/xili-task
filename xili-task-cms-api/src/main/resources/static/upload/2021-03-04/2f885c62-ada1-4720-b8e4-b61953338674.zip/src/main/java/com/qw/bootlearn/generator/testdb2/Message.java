package com.qw.bootlearn.generator.testdb2;

import java.io.Serializable;
import lombok.Data;

/**
 * message
 * @author 
 */
@Data
public class Message implements Serializable {
    private Long id;

    private String content;

    private String name;

    private static final long serialVersionUID = 1L;
}