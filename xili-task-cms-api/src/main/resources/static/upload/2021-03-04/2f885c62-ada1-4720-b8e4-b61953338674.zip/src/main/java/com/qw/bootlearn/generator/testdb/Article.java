package com.qw.bootlearn.generator.testdb;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * article
 * @author 
 */
@Data
public class Article implements Serializable {
    private Integer id;

    private String author;

    private String title;

    private String content;

    private Date createTime;

    private static final long serialVersionUID = 1L;
}