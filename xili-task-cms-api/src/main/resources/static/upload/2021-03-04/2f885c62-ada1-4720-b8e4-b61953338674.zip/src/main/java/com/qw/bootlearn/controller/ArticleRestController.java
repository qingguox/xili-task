package com.qw.bootlearn.controller;

import com.qw.bootlearn.model.AjaxResponse;
import com.qw.bootlearn.model.ArticleVO;
import com.qw.bootlearn.service.ArticleRestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/rest")
public class ArticleRestController {

    @Resource
    public ArticleRestService articleRestService;

    //增加一篇Article ，使用POST方法
//    @RequestMapping(value = "/article", method = POST, produces = "application/json")
    @PostMapping("/article")
    public AjaxResponse saveArticle(@RequestBody ArticleVO article) {
        articleRestService.saveArticle(article);
        return  AjaxResponse.success(article);
    }
 
    
    //删除一篇Article，使用DELETE方法，参数是id
    @DeleteMapping("/article/{id}")
    public AjaxResponse deleteArticle(@PathVariable Long id) {
        articleRestService.deleteArticle(id);
        return AjaxResponse.success(id);
    }
 
     //更新一篇Article，使用PUT方法，以id为主键进行更新
    @PutMapping("/article/{id}")
    public AjaxResponse updateArticle(@PathVariable Long id, @RequestBody ArticleVO article) {
        articleRestService.updateArticle(article);
        return AjaxResponse.success(article);
    }
 
    //获取一篇Article，使用GET方法
    @GetMapping("/article/{id}")
    public AjaxResponse getArticleById(@PathVariable Long id) {
        ArticleVO article = articleRestService.getArticle(id);
        return AjaxResponse.success(article);
    }
    @GetMapping("/article")
    public AjaxResponse getArticle() {

        List<ArticleVO> articles = articleRestService.getAll();
        return AjaxResponse.success(articles);
    }
}