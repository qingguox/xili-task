package com.qw.bootlearn.service;

import com.qw.bootlearn.generator.testdb.Article;
import com.qw.bootlearn.generator.testdb.ArticleMapper;
import com.qw.bootlearn.generator.testdb2.Message;
import com.qw.bootlearn.generator.testdb2.MessageMapper;
import com.qw.bootlearn.model.ArticleVO;
import com.qw.bootlearn.utils.DozerUtils;
import org.dozer.Mapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
public class ArticleMybatisRestService implements ArticleRestService {

    @Resource
    protected Mapper dozerMapper;

    @Resource
    private ArticleMapper articleMapper;

    @Resource
    private MessageMapper messageMapper;

    //新增
    @Override
    @Transactional
    public ArticleVO saveArticle(ArticleVO article) {
        Article articlePO = dozerMapper.map(article, Article.class);
        articleMapper.insert(articlePO);

        Message message = new Message();
        message.setName("庆伟");
        message.setContent("很牛逼 ");
        messageMapper.insert(message);

//        int a = 2/0;     //认为制造被除数为0的异常
        return article;
    }

    //删除
    @Override
    public void deleteArticle(Long id) {
        articleMapper.deleteByPrimaryKey(Math.toIntExact(id));
    }

    //更新
    @Override
    public void updateArticle(ArticleVO article) {
        Article articlePO = dozerMapper.map(article,Article.class);
        articleMapper.updateByPrimaryKeySelective(articlePO);
    }

    //查询
    @Override
    public ArticleVO getArticle(Long id) {
        return dozerMapper.map(articleMapper.selectByPrimaryKey(Math.toIntExact(id)),ArticleVO.class);
    }
    //查询所有
    @Override
    public List<ArticleVO> getAll() {
        List<Article> articles = articleMapper.selectByExample(null);
        return DozerUtils.mapList(articles,ArticleVO.class);
    }
}