package com.qw.bootlearn.controller;

import com.qw.bootlearn.model.ArticleVO;
import com.qw.bootlearn.service.ArticleRestService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
public class HelloController {

    @Resource
    public ArticleRestService articleRestService;


    @RequestMapping("/hello")
    public void hello(String name) {

        List<ArticleVO> all = articleRestService.getAll();
        for (ArticleVO l : all) {
            System.out.println(l);
        }
    }

    @GetMapping("/article/")
    public String getArticle() {
         return null;
    }

}