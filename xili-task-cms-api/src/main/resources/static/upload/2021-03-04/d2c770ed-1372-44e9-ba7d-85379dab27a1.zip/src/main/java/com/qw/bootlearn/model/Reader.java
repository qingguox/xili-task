package com.qw.bootlearn.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public  class Reader {
        /**
         * name : zimug
         * age : 18
         */
        private String name;
        private int age;

}